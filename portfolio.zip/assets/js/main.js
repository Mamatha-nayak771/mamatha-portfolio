
/* Main interactivity for portfolio */
(function(){
  // Theme toggle
  const root = document.documentElement;
  const toggle = document.getElementById('theme-toggle');
  const saved = localStorage.getItem('theme');
  if(saved === 'dark') document.documentElement.setAttribute('data-theme','dark');
  toggle.addEventListener('click', () => {
    const now = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    if(now === 'dark') document.documentElement.setAttribute('data-theme','dark'); else document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('theme', now);
  });

  // Mobile menu toggle
  const menuBtn = document.getElementById('menu-toggle');
  const navLinks = document.getElementById('nav-links');
  menuBtn.addEventListener('click', ()=> {
    if(navLinks.style.display === 'flex') navLinks.style.display = ''; else navLinks.style.display = 'flex';
  });

  // Contact form: open mail client with prefilled message
  const form = document.getElementById('contact-form');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('cf-name').value.trim();
    const email = document.getElementById('cf-email').value.trim();
    const msg = document.getElementById('cf-message').value.trim();
    const subject = encodeURIComponent('Portfolio contact from ' + name);
    const body = encodeURIComponent('Name: ' + name + '\nEmail: ' + email + '\n\n' + msg);
    window.location.href = `mailto:your.email@example.com?subject=${subject}&body=${body}`;
  });

  // Simple certificates carousel
  const track = document.querySelector('.carousel-track');
  const prev = document.getElementById('prev-cert');
  const next = document.getElementById('next-cert');
  let idx = 0;
  const cards = document.querySelectorAll('.cert-card');
  const cardWidth = cards[0] ? cards[0].getBoundingClientRect().width + 16 : 260;

  function updateCarousel(){
    track.style.transform = `translateX(${-idx * cardWidth}px)`;
  }
  if(next) next.addEventListener('click', ()=> { idx = Math.min(idx+1, cards.length-1); updateCarousel(); });
  if(prev) prev.addEventListener('click', ()=> { idx = Math.max(idx-1, 0); updateCarousel(); });
})();
