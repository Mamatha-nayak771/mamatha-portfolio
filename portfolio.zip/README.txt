Instructions
------------
- Replace assets/img/profile.svg with your photo (same file name) or update <img> src in index.html.
- Edit links: update email in contact form and LinkedIn URL in header/footer.
- Project cards have placeholder buttons — update hrefs inside index.html to point to live demos and GitHub repos.
- To view locally: open index.html in a browser.
- To deploy: push to GitHub and enable GitHub Pages (or use Netlify/Vercel). This is a static site (HTML/CSS/JS).

Files
-----
index.html
assets/css/style.css
assets/js/main.js
assets/img/profile.svg
assets/mamatha_resume.pdf
